const nome = document.getElementById('nome'); 
const descricao = document.getElementById('descricao'); 
const url = document.getElementById('url'); 
const form = document.getElementById('form');
const error = document.querySelectorAll('.error'); 
const formItem = document.querySelectorAll('.formItem');

form .addEventListener('submit',  (e) =>{ 
    
    checkNome();
    checkDescricao(); 
    checkUrl(); 

    function checkNome(){
        let mensagemError = [];
        if (nome.value === '' || nome.value == null) {
            e.preventDefault();  
            mensagemError.push ("Preencha o campo nome!"); 
            error[0].innerText = mensagemError; 
            formItem[0].classList.add('fail');
        } 
        else {
            formItem[0].classList.remove('fail');
            error[0].innerText = null; 
            formItem[0].classList.add('sucess');
        }
    }

    function checkDescricao(){
        let mensagemError = [];
        if (descricao.value === '' || descricao.value == null) {
            e.preventDefault();  
            mensagemError.push ("Preencha o campo descrição!"); 
            error[1].innerText = mensagemError; 
            formItem[1].classList.add('fail');
        } 
        else {
            formItem[1].classList.remove('fail');
            error[1].innerText = null; 
            formItem[1].classList.add('sucess');
        }
    } 

    function checkUrl(){ 
        let mensagemError = [];
        if (url.value === '' || url.value == null) {
            e.preventDefault();  
            mensagemError.push ("Preencha o campo URL!"); 
            error[2].innerText = mensagemError; 
            formItem[2].classList.add('fail');
        } 
        else {
            formItem[2].classList.remove('fail');
            error[2].innerText = null; 
            formItem[2].classList.add('sucess');
        }
    }
});

